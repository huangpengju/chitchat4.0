# Weave UI

Vue3 + Vite.js supported

## Run

install dependencies
```
npm i
```

run dev
```
npm run dev
```
