<template>
  <Group :listAll=false />
</template>

<script setup>
import Group from '@/components/Group.vue'

</script>
