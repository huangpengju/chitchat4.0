<template>
  <Group listAll />
</template>

<script setup>
import Group from '@/components/Group.vue'

</script>
