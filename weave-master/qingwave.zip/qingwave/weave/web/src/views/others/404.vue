<template>
  <div class="h-full w-full flex">
    <div class="flex-col m-auto justify-center text-center">
      <h1 class="font-bold text-2xl">Not Found</h1>
      <div class="flex my-[4rem]">
        <img src="@/assets/404.svg" class="w-1/3 mx-auto" >
      </div>
      <el-button><router-link to="/">Go Home</router-link></el-button>
    </div>
  </div>
</template>

<script setup>
</script>
